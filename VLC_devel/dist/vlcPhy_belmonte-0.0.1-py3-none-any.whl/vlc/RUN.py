from VLC import VLC
# import vlcPhy

if __name__ == "__main__":
    
    print("Starting VLC Simulator...")
    
    # vlc_obj = VLC()