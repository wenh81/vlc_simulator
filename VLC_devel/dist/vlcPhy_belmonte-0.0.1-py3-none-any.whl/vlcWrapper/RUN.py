# from VLC import VLC
from . import TEST

# if __name__ == "__main__":
    
#     print("Starting VLC Simulator...")
    
#     vlc_obj = VLC()