
print("Starting VLC Simulator...")