print("Init vlcWrapper")

from vlcPhy.VLC import VLC