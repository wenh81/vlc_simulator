
from vlcPhy.VLC import VLC

class simulVLC(object):
    
    def __init__(self):
        """Constructor"""
        
        print("Starting VLC Simulation!")
        
        vlc_obj = VLC()