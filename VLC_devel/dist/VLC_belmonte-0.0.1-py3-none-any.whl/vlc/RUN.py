from VLC import VLC

if __name__ == "__main__":
    
    print("Starting VLC Simulator...")
    
    vlc_obj = VLC()